#include "demo002.h"
#include <QtGui/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Demo002 w;
	w.show();
	return a.exec();
}
