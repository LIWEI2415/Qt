
#include <stdio.h>
#include <string.h>
#include "DataSource.h"

DataSource::DataSource()
{

}

DataSource::~DataSource()
{

}


// ����
int DataSource::load()
{
	FILE* fp = fopen("local.data", "rb");
	if(!fp) return 0;

	m_records.clear(); // ���

	// ��������	
	while( !feof(fp))
	{
		Student record;
		int n = fread(&record, 1, sizeof(Student), fp);
		if( n < 0 ) break;
		if( n == 0) continue;

		m_records.push_back(record);
	}

	fclose(fp);
	return 0;
}

// ����
int DataSource::save()
{
	FILE* fp = fopen("local.data", "wb");
	if(!fp) return -1;

	// ����ÿ����¼
	for(StudentList::iterator iter = m_records.begin();
		iter != m_records.end(); iter ++)
	{
		Student& record = *iter;
		fwrite(&record, 1, sizeof(Student), fp);
	}

	fclose(fp);
	return 0;
}

// ����
int DataSource::add(const Student& stu)
{
	m_records.push_back(stu);
	return 0;
}

// ɾ��
void DataSource::remove(int id)
{
	for(StudentList::iterator iter = m_records.begin();
		iter != m_records.end(); iter ++)
	{
		Student& record = *iter;
		if(record.id == id)
		{
			m_records.erase(iter);
			break;
		}
	}
}

// ��ѧ�Ų��� 
Student* DataSource::find(int id)
{
	for(StudentList::iterator iter = m_records.begin();
		iter != m_records.end(); iter ++)
	{
		Student& record = *iter;
		if(record.id == id)
		{
			return &record;
		}
	}
	return NULL;
}

// ������ƥ�����
void DataSource::match(const char* name, StudentList& results)
{
	for(StudentList::iterator iter = m_records.begin();
		iter != m_records.end(); iter ++)
	{
		Student& record = *iter;
		// ��׼C��Ĳ��Һ���
		if( strstr(record.name, name) != NULL) 
		{
			results.push_back(record);
		}
	}	
}




