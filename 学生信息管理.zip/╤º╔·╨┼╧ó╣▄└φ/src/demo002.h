#ifndef DEMO002_H
#define DEMO002_H

#include <QtGui>
#include <QtGui/QWidget>
#include "ui_demo002.h"

#include "DataSource.h"

class Demo002 : public QWidget
{
	Q_OBJECT

public:
	Demo002(QWidget *parent = 0, Qt::WFlags flags = 0);
	~Demo002();

private slots:
	int onAdd();
	int onRemove();
	int onFilterChanged();

private:
	void display(Student& record);
	void display(StudentList& records);

private:
	Ui::Demo002Class ui;
	DataSource m_dataSource;
};

#endif // DEMO002_H
