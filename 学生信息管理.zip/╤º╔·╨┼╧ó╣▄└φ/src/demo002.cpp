#include "demo002.h"
#include "GBK.h"
#include "DlgNew.h"

Demo002::Demo002(QWidget *parent, Qt::WFlags flags)
	: QWidget(parent, flags)
{
	ui.setupUi(this);

	connect(ui.btnAdd, SIGNAL(clicked()), this, SLOT(onAdd()));
	connect(ui.btnRemove, SIGNAL(clicked()), this, SLOT(onRemove()));
	connect(ui.m_ctlFilter, SIGNAL(returnPressed()), this, SLOT(onFilterChanged()));

	// ����
	m_dataSource.load();

	// ��ʾ
	onFilterChanged();
}

Demo002::~Demo002()
{
	
}

int Demo002::onAdd()
{
	Student result;
	DlgNew dlg(&result, this);
	if(QDialog::Accepted == dlg.exec())
	{
		// ����
		m_dataSource.add(result);
		m_dataSource.save();

		// ��ʾ������
		display(result);
	}
	return 0;
}

int Demo002::onRemove()
{
	QTreeWidgetItem* item = ui.treeWidget->currentItem();
	if(!item) return 0; // û��ѡ����

	// ȡ���к�
	int id = item->data(0, Qt::UserRole).toInt();

	// ��DataSource��ɾ����¼
	m_dataSource.remove(id);
	m_dataSource.save();

	// �ӽ�����ɾ��������ʾ
	int index = ui.treeWidget->indexOfTopLevelItem(item);
	QTreeWidgetItem* which = ui.treeWidget->takeTopLevelItem(index);
	delete which;

	return 0;
}

// ����
int Demo002::onFilterChanged()
{	
	string filter = GBK::FromUnicode(ui.m_ctlFilter->text().trimmed());
	
	if(filter.length() > 0)
	{
		// ����ƥ��
		StudentList results;
		m_dataSource.match(filter.c_str(), results);

		// ��ʾƥ��ļ�¼
		ui.treeWidget->clear();
		display(results);
	}
	else
	{
		// ��ʾȫ��
		ui.treeWidget->clear();
		display(m_dataSource.list());
	}	
	
	return 0;
}

// ��ʾһ����¼
void Demo002::display(Student& record)
{
	// ��������
	QTreeWidgetItem* item = new QTreeWidgetItem(ui.treeWidget);
	item->setText(0, QString("%1").arg(record.id) );
	item->setText(1, GBK::ToUnicode(record.name));
	item->setText(2, record.cellphone);

	// �����к�
	item->setData(0, Qt::UserRole, record.id);
}

// ��ʾ������¼
void Demo002::display(StudentList& records)
{
	for(StudentList::iterator iter = records.begin();
		iter != records.end(); iter ++)
	{
		Student& record = *iter;

		display(record);
	}
}

