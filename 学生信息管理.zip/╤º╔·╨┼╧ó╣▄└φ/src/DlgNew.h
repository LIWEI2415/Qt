#ifndef DLGNEW_H
#define DLGNEW_H

#include <QDialog>
#include "ui_DlgNew.h"

#include "Student.h"

class DlgNew : public QDialog
{
	Q_OBJECT

public:
	DlgNew(Student* result, QWidget *parent = 0);
	~DlgNew();

private slots:
	int onBtnOK();
	int onBtnCancel();

private:
	Ui::DlgNew ui;
	Student* m_result;
};

#endif // DLGNEW_H
