#ifndef _STUDENT_H
#define _STUDENT_H

#include <list>
using namespace std;

// һ����¼
class Student
{
public:
	Student(): id(0) {}

public:
	int id;
	char name[32];
	char cellphone[12];
};

// �б�
typedef list<Student> StudentList;

#endif

